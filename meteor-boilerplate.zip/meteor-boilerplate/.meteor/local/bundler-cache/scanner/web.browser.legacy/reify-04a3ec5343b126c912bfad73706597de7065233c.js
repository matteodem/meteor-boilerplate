module.link('./hot-api.js',{makeApplyHmr:"makeApplyHmr"},0);
